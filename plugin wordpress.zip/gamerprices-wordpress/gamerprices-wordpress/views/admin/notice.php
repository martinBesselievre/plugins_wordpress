<div class="updated">
	<div class="gamerprices_activate">
		<img src="<?php echo GAMERPRICES__PLUGIN_URL . '_inc/img/gp-fav-48.png'; ?>" alt="GamerPrices" />
		<span style="color: #000080;">
			<span style="color: #000080;">
				<strong><span style="color: #333333;">Gamer</span></strong>
				<span style="color: #ffc000;"><strong>Prices</strong></span>
			</span>
		</span>
		<p>
			<a href="<?php echo GP_Admin::get_page_url()?>" class="button">Cliquez ici</a> <?php esc_html_e('to activate your GamerPrices account and wordpress widgets', 'gamerprices');?> 
		</p>
	</div>
</div>